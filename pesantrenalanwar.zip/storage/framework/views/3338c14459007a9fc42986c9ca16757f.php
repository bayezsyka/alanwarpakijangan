

<section class=" py-16 sm:py-24">

    <div class="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-16">
            <h1 class="text-xl sm:text-2xl md:text-3xl font-medium tracking-wider">
                <span class="text-white bg-[#008362] px-4 py-2 rounded-lg shadow-lg">Galeri</span>
                <span class="text-[#008362]">Acara</span>
            </h1>
        </div>
       
        <div class="space-y-16">
            <?php $__empty_1 = true; $__currentLoopData = $latestEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div>
                    <h3 class="text-2xl font-semibold text-gray-800 mb-2"><?php echo e($event->nama_acara); ?></h3>
                    <?php if($event->tanggal): ?>
                        <p class="text-sm text-gray-500 mb-6"><?php echo e(\Carbon\Carbon::parse($event->tanggal)->translatedFormat('d F Y')); ?></p>
                    <?php endif; ?>

                    <div class="swiper welcome-gallery-swiper">
                        <div class="swiper-wrapper">
                            <?php $__currentLoopData = $event->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide !w-auto">
                                    <img src="<?php echo e(asset('storage/' . $photo->file_path)); ?>" alt="<?php echo e($event->nama_acara); ?>" 
                                         class="h-48 sm:h-56 md:h-64 rounded-lg shadow-md object-cover">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center py-12">
                    <p class="text-gray-500">Belum ada galeri untuk ditampilkan.</p>
                </div>
            <?php endif; ?>
        </div>

        <?php if($latestEvents->isNotEmpty()): ?>
            <div class="text-center mt-16">
                <a href="<?php echo e(route('galeri.index')); ?>" class="px-8 py-3 bg-[#008362] text-white font-semibold rounded-lg shadow-md hover:bg-[hsl(186,100%,26%)]">
                    Lihat Semua Galeri
                </a>
            </div>
        <?php endif; ?>
    </div>
</section>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        const swiper = new Swiper('.welcome-gallery-swiper', {
            // Konfigurasi
            slidesPerView: 'auto',
            spaceBetween: 16, // Jarak antar gambar
            speed: 5000, // Kecepatan transisi animasi
            loop: true,
            freeMode: true,
            autoplay: {
                delay: 1, // Delay 1ms untuk scroll berkelanjutan
                disableOnInteraction: false, // Lanjutkan autoplay setelah interaksi pengguna
                pauseOnMouseEnter: true, // Berhenti saat mouse hover
            },
        });
    });
</script><?php /**PATH C:\Coding\Sudah Jalan\pesantrenalanwar\resources\views/welcome/galeri.blade.php ENDPATH**/ ?>