<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="bg-gradient-to-r from-[#059568] to-emerald-600 rounded-xl shadow-lg">
            <div class="px-8 py-6">
                <h2 class="text-2xl font-bold text-white">
                    <?php echo e(__('Dashboard Analisis')); ?>

                </h2>
                <p class="text-emerald-100 mt-2">Pantau dan Kendalikan Data Anda Secara Real-Time</p>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-8">

            
            <div class="bg-white rounded-2xl shadow-xl border border-gray-100 p-6">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-3">
                        <div class="bg-[#059568] p-2 rounded-lg">
                            <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                            </svg>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-800">Jumlah Pengunjung Hari ini</h3>
                    </div>
                    <div class="text-right">
                        <div class="text-3xl font-bold text-emerald-600"><?php echo e($visitorCount); ?></div>
                        <div class="text-sm text-emerald-500">Total Kunjungan</div>
                    </div>
                </div>
            </div>

            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                
                

                
                <div class="bg-white rounded-2xl shadow-xl border border-gray-100 p-6 space-y-6">
                    <div class="flex items-center space-x-3">
                        <div class="bg-[#059568] p-2 rounded-lg">
                            <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M3.75 3v11.25A2.25 2.25 0 0 0 6 16.5h2.25M3.75 3h-1.5m1.5 0h16.5m0 0h1.5m-1.5 0v11.25A2.25 2.25 0 0 1 18 16.5h-2.25m-7.5 0h7.5m-7.5 0-1 3m8.5-3 1 3m0 0 .5 1.5m-.5-1.5h-9.5m0 0-.5 1.5m.75-9 3-3 2.148 2.148A12.061 12.061 0 0 1 16.5 7.605" />
                            </svg>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-800">Artikel Terpopuler</h3>
                    </div>
                    <div class="relative h-[325px]">
                        <canvas id="artikelChart"></canvas>
                    </div>
                </div>
            </div>

            
            <div class="bg-white rounded-2xl shadow-xl border border-gray-100 p-6 space-y-6">
                <div class="flex items-center space-x-3">
                    <div class="bg-[#059568] p-2 rounded-lg">
                        <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M8 7V3m8 4V3m-9 4h10M5 21h14a2 2 0 002-2V7H3v12a2 2 0 002 2z" />
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800">Heatmap Kunjungan</h3>
                </div>
                <div class="relative h-[480px] p-4">
                    <canvas id="heatmapChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const topArticleLabels = <?php echo json_encode($topArticleLabels, 15, 512) ?>;
            const topArticleViews = <?php echo json_encode($topArticleViews, 15, 512) ?>;
            const heatmapRaw = <?php echo json_encode($heatmapData, 15, 512) ?>;
            const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];

            const matrixData = heatmapRaw.map(row => ({
                x: parseInt(row.hour),
                y: parseInt(row.day),
                v: parseInt(row.total)
            }));

            // new Chart(document.getElementById('pendaftarChart'), {
            //     type: 'doughnut',
            //     data: {
            //         labels: pendaftarLabels,
            //         datasets: [{
            //             label: 'Jumlah Pendaftar',
            //             data: pendaftarCounts,
            //             backgroundColor: [
            //                 'rgb(253, 224, 71)',
            //                 'rgb(34, 197, 94)',
            //                 'rgb(239, 68, 68)'
            //             ],
            //             hoverOffset: 4
            //         }]
            //     },
            //     options: { responsive: true, maintainAspectRatio: false }
            // });

            new Chart(document.getElementById('artikelChart'), {
                type: 'bar',
                data: {
                    labels: topArticleLabels,
                    datasets: [{
                        label: 'Total Views',
                        data: topArticleViews,
                        backgroundColor: 'rgba(5, 149, 104, 0.6)',
                        borderColor: 'rgba(5, 149, 104, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    indexAxis: 'y',
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: { x: { beginAtZero: true, ticks: { precision: 0 } } },
                    plugins: { legend: { display: false } }
                }
            });

            new Chart(document.getElementById('heatmapChart'), {
                type: 'matrix',
                data: {
                    datasets: [{
                        label: 'Kunjungan per Jam/Hari',
                        data: matrixData,
                        backgroundColor(ctx) {
                            const value = ctx.raw.v;
                            const alpha = Math.min(1, value / 20);
                            return `rgba(5, 150, 105, ${alpha})`;
                        },
                        width: ctx => 20,
                        height: ctx => 20
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: {
                            type: 'linear',
                            min: 0,
                            max: 23,
                            ticks: {
                                callback: val => `${val}:00`
                            },
                            title: {
                                display: true,
                                text: 'Jam'
                            }
                        },
                        y: {
                            type: 'linear',
                            min: 0,
                            max: 6,
                            reverse: true,
                            ticks: {
                                callback: val => days[val]
                            },
                            title: {
                                display: true,
                                text: 'Hari'
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: ctx => `Jumlah: ${ctx.raw.v}`
                            }
                        },
                        legend: { 
                          position: 'bottom',  
                         }
                    }
                }
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Coding\Sudah Jalan\pesantrenalanwar\resources\views/dashboard.blade.php ENDPATH**/ ?>