<?php $__env->startSection('title', 'Artikel - Pesantren Al-Anwar'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-8 sm:py-12 px-4 sm:px-6 lg:px-8 bg-gray-50 pt-24 pb-16">
    <div class="container mx-auto max-w-7xl">
        
        
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('search-artikel-tamu');

$__html = app('livewire')->mount($__name, $__params, 'lw-493105913-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding\xampp\htdocs\pesantrenalanwar\resources\views/artikel.blade.php ENDPATH**/ ?>