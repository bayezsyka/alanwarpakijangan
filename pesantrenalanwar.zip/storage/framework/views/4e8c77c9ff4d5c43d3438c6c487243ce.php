
<fieldset class="space-y-8 bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
    <legend class="text-xl font-bold text-gray-900 pb-4 w-full border-b border-gray-200">
        <div class="flex items-center gap-3">
            <div class="w-2 h-8 bg-blue-600 rounded-full"></div>
            Data Diri Santri
        </div>
    </legend>
    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="md:col-span-2">
            <label for="nama_lengkap" class="block text-sm font-semibold text-gray-800 mb-2">
                Nama Lengkap <span class="text-red-500">*</span>
            </label>
            <input type="text" name="nama_lengkap" id="nama_lengkap" value="<?php echo e(old('nama_lengkap')); ?>" required 
                   class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 placeholder-gray-400"
                   placeholder="Sesuai Akta Kelahiran">
        </div>
        
        <div>
            <label for="nik" class="block text-sm font-semibold text-gray-800 mb-2">
                NIK <span class="text-red-500">*</span>
            </label>
            <input type="text" name="nik" id="nik" value="<?php echo e(old('nik')); ?>" required pattern="\d{16}"
                   class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 placeholder-gray-400"
                   placeholder="16 digit angka">
        </div>
        
        <div>
            <label for="nisn" class="block text-sm font-semibold text-gray-800 mb-2">
                NISN
            </label>
            <input type="text" name="nisn" id="nisn" value="<?php echo e(old('nisn')); ?>" pattern="\d{10}"
                   class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 placeholder-gray-400"
                   placeholder="10 digit angka (jika ada)">
        </div>
        
        <div>
            <label for="jenis_kelamin" class="block text-sm font-semibold text-gray-800 mb-2">
                Jenis Kelamin <span class="text-red-500">*</span>
            </label>
            <select name="jenis_kelamin" id="jenis_kelamin" required 
                    class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white">
                <option value="">Pilih Jenis Kelamin</option>
                <option value="Laki-laki" <?php if(old('jenis_kelamin') == 'Laki-laki'): echo 'selected'; endif; ?>>Laki-laki</option>
                <option value="Perempuan" <?php if(old('jenis_kelamin') == 'Perempuan'): echo 'selected'; endif; ?>>Perempuan</option>
            </select>
        </div>
        
        <div>
            <label for="tempat_lahir" class="block text-sm font-semibold text-gray-800 mb-2">
                Tempat Lahir <span class="text-red-500">*</span>
            </label>
            <input type="text" name="tempat_lahir" id="tempat_lahir" value="<?php echo e(old('tempat_lahir')); ?>" required 
                   class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 placeholder-gray-400"
                   placeholder="Contoh: Brebes">
        </div>
        
        <div class="md:col-span-2">
            <label for="tanggal_lahir" class="block text-sm font-semibold text-gray-800 mb-2">
                Tanggal Lahir <span class="text-red-500">*</span>
            </label>
            <input type="date" name="tanggal_lahir" id="tanggal_lahir" value="<?php echo e(old('tanggal_lahir')); ?>" required 
                   class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200">
        </div>
        
        <div class="md:col-span-2">
            <label for="alamat" class="block text-sm font-semibold text-gray-800 mb-2">
                Alamat Lengkap <span class="text-red-500">*</span>
            </label>
            <textarea name="alamat" id="alamat" rows="3" required 
                      class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 placeholder-gray-400 resize-none"
                      placeholder="Jl. Pesantren No. 1, Desa Pakijangan, Kec. Bulakamba, Kab. Brebes"><?php echo e(old('alamat')); ?></textarea>
        </div>
    </div>
</fieldset>


<fieldset class="space-y-8 bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mt-8">
    <legend class="text-xl font-bold text-gray-900 pb-4 w-full border-b border-gray-200">
        <div class="flex items-center gap-3">
            <div class="w-2 h-8 bg-green-600 rounded-full"></div>
            Data Orang Tua & Wali
        </div>
    </legend>
    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="space-y-4 p-6 bg-green-50 rounded-xl border border-green-100">
            <h4 class="font-bold text-gray-800 text-lg flex items-center gap-2">
                <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                </svg>
                Data Ayah
            </h4>
            <div>
                <label for="nama_ayah" class="block text-sm font-semibold text-gray-700 mb-2">Nama Ayah <span class="text-red-500">*</span></label>
                <input type="text" name="nama_ayah" id="nama_ayah" value="<?php echo e(old('nama_ayah')); ?>" required 
                       class="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
            </div>
            <div>
                <label for="pekerjaan_ayah" class="block text-sm font-semibold text-gray-700 mb-2">Pekerjaan Ayah <span class="text-red-500">*</span></label>
                <input type="text" name="pekerjaan_ayah" id="pekerjaan_ayah" value="<?php echo e(old('pekerjaan_ayah')); ?>" required 
                       class="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
            </div>
            <div>
                <label for="telepon_ayah" class="block text-sm font-semibold text-gray-700 mb-2">Telepon Ayah <span class="text-red-500">*</span></label>
                <input type="tel" name="telepon_ayah" id="telepon_ayah" value="<?php echo e(old('telepon_ayah')); ?>" required 
                       class="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                       placeholder="Contoh: 081234567890">
            </div>
        </div>
        
        <div class="space-y-4 p-6 bg-pink-50 rounded-xl border border-pink-100">
            <h4 class="font-bold text-gray-800 text-lg flex items-center gap-2">
                <svg class="w-5 h-5 text-pink-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                </svg>
                Data Ibu
            </h4>
            <div>
                <label for="nama_ibu" class="block text-sm font-semibold text-gray-700 mb-2">Nama Ibu <span class="text-red-500">*</span></label>
                <input type="text" name="nama_ibu" id="nama_ibu" value="<?php echo e(old('nama_ibu')); ?>" required 
                       class="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-all duration-200">
            </div>
            <div>
                <label for="pekerjaan_ibu" class="block text-sm font-semibold text-gray-700 mb-2">Pekerjaan Ibu <span class="text-red-500">*</span></label>
                <input type="text" name="pekerjaan_ibu" id="pekerjaan_ibu" value="<?php echo e(old('pekerjaan_ibu')); ?>" required 
                       class="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-all duration-200">
            </div>
            <div>
                <label for="telepon_ibu" class="block text-sm font-semibold text-gray-700 mb-2">Telepon Ibu <span class="text-red-500">*</span></label>
                <input type="tel" name="telepon_ibu" id="telepon_ibu" value="<?php echo e(old('telepon_ibu')); ?>" required 
                       class="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-all duration-200"
                       placeholder="Contoh: 081234567890">
            </div>
        </div>
        
        <div class="md:col-span-2 space-y-4 p-6 bg-purple-50 rounded-xl border border-purple-100">
            <h4 class="font-bold text-gray-800 text-lg flex items-center gap-2">
                <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                </svg>
                Data Wali (Opsional)
            </h4>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input type="text" name="nama_wali" placeholder="Nama Wali" value="<?php echo e(old('nama_wali')); ?>" 
                       class="px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200">
                <input type="text" name="pekerjaan_wali" placeholder="Pekerjaan Wali" value="<?php echo e(old('pekerjaan_wali')); ?>" 
                       class="px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200">
                <input type="tel" name="telepon_wali" placeholder="Telepon Wali" value="<?php echo e(old('telepon_wali')); ?>" 
                       class="px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200">
                <input type="text" name="hubungan_wali" placeholder="Hubungan dengan Santri" value="<?php echo e(old('hubungan_wali')); ?>" 
                       class="px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200">
            </div>
        </div>
    </div>
</fieldset>


<fieldset class="space-y-8 bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mt-8">
    <legend class="text-xl font-bold text-gray-900 pb-4 w-full border-b border-gray-200">
        <div class="flex items-center gap-3">
            <div class="w-2 h-8 bg-orange-600 rounded-full"></div>
            Riwayat Pendidikan & Berkas
        </div>
    </legend>
    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
            <label for="asal_sekolah" class="block text-sm font-semibold text-gray-800 mb-2">
                Asal Sekolah <span class="text-red-500">*</span>
            </label>
            <input type="text" name="asal_sekolah" id="asal_sekolah" value="<?php echo e(old('asal_sekolah')); ?>" required 
                   class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all duration-200">
        </div>
        
        <div>
            <label for="tahun_lulus" class="block text-sm font-semibold text-gray-800 mb-2">
                Tahun Lulus <span class="text-red-500">*</span>
            </label>
            <input type="number" name="tahun_lulus" id="tahun_lulus" value="<?php echo e(old('tahun_lulus')); ?>" required 
                   class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all duration-200"
                   placeholder="Contoh: 2024" min="1950" max="2030">
        </div>
    </div>
    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
        <div>
            <label for="foto_santri" class="block text-sm font-semibold text-gray-800 mb-3">
                <div class="flex items-center gap-2 mb-2">
                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                    </svg>
                    Foto Santri <span class="text-red-500">*</span>
                </div>
                <span class="text-xs text-gray-500 font-normal">Format: JPG/PNG (Maks. 2MB)</span>
            </label>
            <input type="file" name="foto_santri" id="foto_santri" required 
                   class="w-full text-sm text-gray-500 file:mr-4 file:py-3 file:px-4 file:rounded-xl file:border-0 file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 transition-all duration-200 file:cursor-pointer">
        </div>
        
        <div>
            <label for="scan_kk" class="block text-sm font-semibold text-gray-800 mb-3">
                <div class="flex items-center gap-2 mb-2">
                    <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                    </svg>
                    Scan KK <span class="text-red-500">*</span>
                </div>
                <span class="text-xs text-gray-500 font-normal">Format: PDF/JPG (Maks. 2MB)</span>
            </label>
            <input type="file" name="scan_kk" id="scan_kk" required 
                   class="w-full text-sm text-gray-500 file:mr-4 file:py-3 file:px-4 file:rounded-xl file:border-0 file:font-semibold file:bg-green-50 file:text-green-700 hover:file:bg-green-100 transition-all duration-200 file:cursor-pointer">
        </div>
        
        <div>
            <label for="scan_ijazah" class="block text-sm font-semibold text-gray-800 mb-3">
                <div class="flex items-center gap-2 mb-2">
                    <svg class="w-5 h-5 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                    </svg>
                    Scan Ijazah <span class="text-red-500">*</span>
                </div>
                <span class="text-xs text-gray-500 font-normal">Format: PDF/JPG (Maks. 2MB)</span>
            </label>
            <input type="file" name="scan_ijazah" id="scan_ijazah" required 
                   class="w-full text-sm text-gray-500 file:mr-4 file:py-3 file:px-4 file:rounded-xl file:border-0 file:font-semibold file:bg-orange-50 file:text-orange-700 hover:file:bg-orange-100 transition-all duration-200 file:cursor-pointer">
        </div>
    </div>
</fieldset><?php /**PATH C:\Coding\xampp\htdocs\pesantrenalanwar\resources\views/pendaftaran/form-fields.blade.php ENDPATH**/ ?>