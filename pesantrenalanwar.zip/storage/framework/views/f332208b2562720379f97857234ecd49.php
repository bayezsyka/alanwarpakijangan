

<?php $__env->startSection('title', 'Pendaftaran Santri Baru - Pesantren Al-Anwar'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-gray-50 flex items-center justify-center p-4 pt-24 pb-12">
    <div x-data="pendaftaranForm({ success: <?php echo e(session('registration_success') ? 'true' : 'false'); ?> })"
         class="w-full max-w-4xl bg-white rounded-xl shadow-lg overflow-hidden">

        <!-- Header -->
        <div class="bg-gradient-to-r from-green-600 to-sky-700 p-6 text-white">
            <h1 class="text-2xl font-bold">Pendaftaran Santri Baru</h1>
            <p class="text-sm opacity-90">Pondok Pesantren Al-Anwar Pakijangan</p>
        </div>

        <!-- Step Indicator -->
        <div class="px-6 pt-4" x-show="langkah < 3" x-transition>
            <div class="flex justify-between items-start text-center">
                <div class="w-1/3">
                    <div class="h-8 w-8 mx-auto rounded-full flex items-center justify-center font-bold"
                        :class="langkah >= 1 ? 'bg-green-600 text-white' : 'bg-gray-300 text-gray-600'">1</div>
                    <span class="text-xs mt-1">Verifikasi</span>
                </div>
                <div class="w-1/3">
                    <div class="h-8 w-8 mx-auto rounded-full flex items-center justify-center font-bold"
                        :class="langkah >= 2 ? 'bg-green-600 text-white' : 'bg-gray-300 text-gray-600'">2</div>
                    <span class="text-xs mt-1">Data Diri</span>
                </div>
                <div class="w-1/3">
                    <div class="h-8 w-8 mx-auto rounded-full flex items-center justify-center font-bold"
                        :class="langkah >= 3 ? 'bg-green-600 text-white' : 'bg-gray-300 text-gray-600'">3</div>
                    <span class="text-xs mt-1">Selesai</span>
                </div>
            </div>
        </div>

        <!-- Main Form Area -->
        <div class="p-6 md:p-8">

            <!-- 🔸 Langkah 2: Form Data Diri (langsung tampil, OTP dilewati) -->
            <div x-show="langkah === 2" x-transition>
                <?php if($errors->any()): ?>
                    <div class="mb-6 bg-red-100 border-l-4 border-red-500 text-red-700 p-4" role="alert">
                        <p class="font-bold">Error dari Server!</p>
                        <p>Data yang Anda kirim masih belum valid. Mohon periksa kembali.</p>
                    </div>
                <?php endif; ?>

                <form id="registrationForm" x-ref="form"
                      action="<?php echo e(route('pendaftaran.store')); ?>"
                      method="POST" enctype="multipart/form-data" class="space-y-8">
                    <?php echo csrf_field(); ?>
                    <!-- Nomor WA dummy sementara -->
                    <input type="hidden" name="nomor_wa" :value="verifiedNomorWa">
                    <?php echo $__env->make('pendaftaran.form-fields', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div class="pt-4 border-t flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3">
                        <button type="button" @click="validateForm"
                                class="w-full sm:w-auto flex justify-center items-center py-3 px-6 border border-gray-300 rounded-md shadow-sm text-base font-medium text-gray-700 bg-white hover:bg-gray-50">
                            Cek Validitas Data
                        </button>
                        <button type="submit" :disabled="!isFormValid"
                                class="w-full sm:w-auto flex justify-center items-center py-3 px-6 border rounded-md shadow-sm text-base font-medium text-white bg-green-600 hover:bg-green-700 disabled:bg-green-300 disabled:cursor-not-allowed">
                            Kirim Formulir
                        </button>
                    </div>
                </form>
            </div>

            <!-- Langkah 3: Selesai -->
            <div x-show="langkah === 3" x-transition.opacity class="text-center py-12">
                <div class="w-24 h-24 bg-green-100 rounded-full p-4 flex items-center justify-center mx-auto">
                    <svg class="w-16 h-16 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M5 13l4 4L19 7"></path>
                    </svg>
                </div>
                <h2 class="text-2xl font-bold text-gray-800 mt-6">Pendaftaran Berhasil!</h2>
                <p class="text-gray-600 mt-2 max-w-md mx-auto">
                    Terima kasih, data Anda telah kami terima. Notifikasi berisi link grup WhatsApp telah dikirim ke nomor Anda.
                </p>
                <div class="mt-8" x-show="showHomeButton" x-transition.enter.duration.500ms>
                    <a href="<?php echo e(route('welcome')); ?>"
                       class="inline-block px-8 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700">
                        Kembali ke Beranda
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function pendaftaranForm(config) {
        return {
            langkah: 2, // ⬅️ Langsung ke form (OTP dilewati)
            isFormValid: false,
            showHomeButton: false,
            nomorWaInput: '',
            verifiedNomorWa: '6280000000000', // ⬅️ Nomor WA dummy sementara
            loading: false,
            errorMessage: '',
            otpSent: false,
            otp: Array(6).fill(''),
            otpErrorMessage: '',

            init() {
                if (config.success) {
                    this.langkah = 3;
                    setTimeout(() => { this.showHomeButton = true; }, 2000);
                }
            },

            // Validasi AJAX NIK
            validateForm() {
                const form = this.$refs.form;
                this.isFormValid = false;
                if (form.checkValidity()) {
                    this.loading = true;
                    fetch('<?php echo e(route('pendaftaran.ajax_validate')); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                        },
                        body: JSON.stringify({ nik: document.getElementById('nik').value })
                    })
                        .then(res => {
                            if (!res.ok) { return res.json().then(err => { throw err; }); }
                            return res.json();
                        })
                        .then(data => {
                            this.isFormValid = true;
                            Swal.fire('Data Valid!', 'Semua data yang dicek sudah benar. Silakan kirim formulir.', 'success');
                        })
                        .catch(error => {
                            const errorMessages = Object.values(error.errors).flat();
                            Swal.fire('Data Tidak Valid!', errorMessages.join('\n'), 'error');
                        })
                        .finally(() => {
                            this.loading = false;
                        });
                } else {
                    form.reportValidity();
                    Swal.fire('Oops!', 'Masih ada data yang belum diisi atau tidak sesuai format. Silakan periksa kembali.', 'error');
                }
            },
        }
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding\xampp\htdocs\pesantrenalanwar\resources\views/pendaftaran/pendaftaran.blade.php ENDPATH**/ ?>