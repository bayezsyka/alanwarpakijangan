<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="bg-gradient-to-r from-[#059568] to-emerald-600 rounded-xl shadow-lg">
            <div class="px-8 py-6">
                <h2 class="text-2xl font-bold text-white">Data Pendaftar Santri</h2>
                <p class="text-emerald-100 mt-2">Kelola data calon santri yang telah mendaftar.</p>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="max-w-7xl mx-auto px-6 lg:px-8">
            <?php if(session('success')): ?>
                <div class="mb-6 bg-emerald-50 border-l-4 border-[#059568] p-4 rounded-r-lg">
                    <p class="text-emerald-800 font-medium"><?php echo e(session('success')); ?></p>
                </div>
            <?php endif; ?>

            <div class="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
                <div class="p-8">
                    <div class="overflow-x-auto border border-gray-200 rounded-lg">
                        <table class="min-w-full bg-white text-sm text-left">
                            <thead class="bg-gray-50 text-gray-700 uppercase">
                                <tr>
                                    <th class="py-3 px-6">Nama Lengkap</th>
                                    <th class="py-3 px-6">Nomor WA</th>
                                    <th class="py-3 px-6">Status</th>
                                    <th class="py-3 px-6">Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                <?php $__empty_1 = true; $__currentLoopData = $pendaftarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendaftar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="py-4 px-6 font-medium text-gray-800"><?php echo e($pendaftar->nama_lengkap); ?></td>
                                        <td class="py-4 px-6 text-gray-600"><?php echo e($pendaftar->nomor_wa); ?></td>
                                        <td class="py-4 px-6">
                                            <span class="px-3 py-1 inline-flex text-xs font-semibold rounded-full <?php echo e($pendaftar->status == 'diterima' ? 'bg-green-100 text-green-800' :
                                                ($pendaftar->status == 'ditolak' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800')); ?>">
                                                <?php echo e(ucfirst($pendaftar->status)); ?>

                                            </span>
                                        </td>
                                        <td class="py-4 px-6">
                                            <a href="<?php echo e(route('admin.pendaftaran.show', $pendaftar->id)); ?>" class="text-indigo-600 hover:text-indigo-900 font-semibold mr-4">Detail</a>
                                            <form id="delete-form-<?php echo e($pendaftar->id); ?>" action="<?php echo e(route('admin.pendaftaran.destroy', $pendaftar->id)); ?>" method="POST" class="inline-block">
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                <button type="button" onclick="confirmDelete(<?php echo e($pendaftar->id); ?>)" class="text-red-600 hover:text-red-900 font-semibold">Hapus</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="py-8 px-6 text-center text-gray-500">Belum ada data pendaftar.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-6"><?php echo e($pendaftarans->links()); ?></div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        function confirmDelete(id) {
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Data yang dihapus tidak dapat dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('delete-form-' + id).submit();
                }
            });
        }
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Coding\xampp\htdocs\pesantrenalanwar\resources\views/admin/pendaftaran/index.blade.php ENDPATH**/ ?>